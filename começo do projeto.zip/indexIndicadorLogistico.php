<?php
    require_once "controller/IndicadorLogisticoController.php";

    $controller = new IndicadorLogisticoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codIndicadorLogistico'] ?? null;
        $data_referencia = $_POST['data_referencia'] ?? '';
        $tempo_medio_entrega = $_POST['tempo_medio_entrega'] ?? '';
        $taxa_entregas_no_prazo = $_POST['taxa_entregas_no_prazo'] ?? '';
        $custo_operacional_rota = $_POST['custo_operacional_rota'] ?? '';
        $eficiencia_transportadora = $_POST['eficiencia_transportadora'] ?? '';
        $codTransportadora = $_POST['codTransportadora'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formIndicadorLogistico.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>