<?php
    require_once "controller/ArmazemController.php";

    $controller = new ArmazemController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codArmazem'] ?? null;
        $nome = $_POST['nome'] ?? '';
        $codEndereco = $_POST['codEndereco'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($nome, $codEndereco);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $nome, $codEndereco);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formArmazem.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>