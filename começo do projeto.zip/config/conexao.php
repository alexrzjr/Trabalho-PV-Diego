<?php
    class Conexao{
        public static function conectar(){
           try{ 
             return new PDO("mysql:host=localhost;dbname=gestao_lojistica","root", "root");
           } catch (PDOException $e){
             die("Erro: ".$e->getMessage());
           }
        }
    }