<?php
    require_once "congif/conexao.php";

    class Entrega {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Entrega");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Entrega WHERE codEntrega = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega) {
            $result = $this->pdo->prepare("INSERT INTO Entrega (volume, peso, prazo_entrega, codVeiculo, codMotorista, codTransportadora, codRota, codProduto, statusEntrega) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            return $result->execute([$volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega]);
        }

        public function alterar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega, $cod) {
            $result = $this->pdo->prepare("UPDATE Entrega SET volume = ?, peso = ?, prazo_entrega = ?, codVeiculo = ?, codMotorista = ?, codTransportadora = ?, codRota = ?, codProduto = ?, statusEntrega = ? WHERE codEntrega = ?");
            return $result->execute([$volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Entrega WHERE codEntrega = ?");
            return $result->execute([$cod]);
        }
    }
?>