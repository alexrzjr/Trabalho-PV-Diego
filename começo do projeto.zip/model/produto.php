<?php
    require_once "congif/conexao.php";

    class Produto {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Produto");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Produto WHERE codProduto = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($nome, $categoriaProduto) {
            $result = $this->pdo->prepare("INSERT INTO Produto (nome, categoriaProduto) VALUES (?, ?)");
            return $result->execute([$nome, $categoriaProduto]);
        }

        public function alterar($nome, $categoriaProduto, $cod) {
            $result = $this->pdo->prepare("UPDATE Produto SET nome = ?, categoriaProduto = ? WHERE codProduto = ?");
            return $result->execute([$nome, $categoriaProduto, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Produto WHERE codProduto = ?");
            return $result->execute([$cod]);
        }
    }
?>