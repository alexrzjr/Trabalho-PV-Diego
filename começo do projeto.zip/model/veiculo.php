<?php
    require_once "congif/conexao.php";

    class Veiculo {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Veiculo");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Veiculo WHERE codVeiculo = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo) {
            $result = $this->pdo->prepare("INSERT INTO Veiculo (placa, capacidade_carga, codMotorista, codTransportadora, statusVeiculo, categoriaVeiculo)
                                        VALUES (?, ?, ?, ?, ?, ?)");
            return $result->execute([$placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo]);
        }

        public function alterar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo, $cod) {
            $result = $this->pdo->prepare("UPDATE Veiculo SET placa = ?, capacidade_carga = ?, codMotorista = ?, codTransportadora = ?, statusVeiculo = ?, categoriaVeiculo = ?
                                        WHERE codVeiculo = ?");
            return $result->execute([$placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Veiculo WHERE codVeiculo = ?");
            return $result->execute([$cod]);
        }
    }
?>