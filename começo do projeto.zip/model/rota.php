<?php
    require_once "congif/conexao.php";

    class Rota {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Rota");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Rota WHERE codRota = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($origem, $destino, $distancia_km, $duracao_prevista) {
            $result = $this->pdo->prepare("INSERT INTO Rota (origem, destino, distancia_km, duracao_prevista) VALUES (?, ?, ?, ?)");
            return $result->execute([$origem, $destino, $distancia_km, $duracao_prevista]);
        }

        public function alterar($origem, $destino, $distancia_km, $duracao_prevista, $cod) {
            $result = $this->pdo->prepare("UPDATE Rota SET origem = ?, destino = ?, distancia_km = ?, duracao_prevista = ? WHERE codRota = ?");
            return $result->execute([$origem, $destino, $distancia_km, $duracao_prevista, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Rota WHERE codRota = ?");
            return $result->execute([$cod]);
        }
    }
?>