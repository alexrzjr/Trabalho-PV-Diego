<?php
    require_once "congif/conexao.php";

    class Endereco {
        private $pdo;

        public function __construct()
        {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos(){
            $result = $this->pdo->query("SELECT * FROM Endereco");
            return $result->fetchAll(
                PDO::FETCH_ASSOC);
        }

        public function listaId($cod){
            $result = $this->pdo->prepare("SELECT * FROM Endereco WHERE codEndereco = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($logradouro, $numero, $bairro, $cep, $cidade, $uf){
            var_dump($logradouro);
            var_dump($numero);
            var_dump($bairro);
            var_dump($cep);
            var_dump($cidade);
            var_dump($uf);
            $result = $this->pdo->prepare("INSERT INTO Endereco (nome, logradouro, numero, bairro, cep, cidade, uf) 
                                            VALUES (?, ?, ?, ?, ?, ?, ?)");
            return $result->execute([$logradouro, $numero, $bairro, $cep, $cidade, $uf]);
        }

        public function alterar($codEndereco, $cod){
            $result = $this->pdo->prepare("UPDATE Endereco SET logradouro=?, numero=?, bairro=?, cep=?, cidade=?, uf=?
                                            WHERE logradouro = ?");
            return $result->execute([$codEndereco, $cod]);
        }

        public function excluir($cod){
            $result = $this->pdo->prepare("DELETE FROM Endereco 
                                            WHERE codEndereco = ?");
            return $result->execute([$cod]);
        }
    }
?>