<?php
    require_once "congif/conexao.php";

    class Transportadora {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Transportadora");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Transportadora WHERE codTransportadora = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco) {
            $result = $this->pdo->prepare("INSERT INTO Transportadora (cnpj, nome_fantasia, razao_social, IE, contato, codEndereco) VALUES (?, ?, ?, ?, ?, ?)");
            return $result->execute([$cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco]);
        }

        public function alterar($cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco, $cod) {
            $result = $this->pdo->prepare("UPDATE Transportadora SET cnpj = ?, nome_fantasia = ?, razao_social = ?, IE = ?, contato = ?, codEndereco = ? WHERE codTransportadora = ?");
            return $result->execute([$cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Transportadora WHERE codTransportadora = ?");
            return $result->execute([$cod]);
        }
    }
?>