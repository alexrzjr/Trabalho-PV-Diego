<?php
    require_once "congif/conexao.php";

    class Motorista {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Motorista");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Motorista WHERE codMotorista = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($nome, $cnh, $telefone, $codTransportadora) {
            $result = $this->pdo->prepare("INSERT INTO Motorista (nome, cnh, telefone, codTransportadora) VALUES (?, ?, ?, ?)");
            return $result->execute([$nome, $cnh, $telefone, $codTransportadora]);
        }

        public function alterar($nome, $cnh, $telefone, $codTransportadora, $cod) {
            $result = $this->pdo->prepare("UPDATE Motorista SET nome = ?, cnh = ?, telefone = ?, codTransportadora = ? WHERE codMotorista = ?");
            return $result->execute([$nome, $cnh, $telefone, $codTransportadora, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Motorista WHERE codMotorista = ?");
            return $result->execute([$cod]);
        }
    }
?>