<?php
    require_once "congif/conexao.php";

    class Rastreamento {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Rastreamento");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Rastreamento WHERE codRastreamento = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($data_hora, $latitude, $longitude, $codEntrega) {
            $result = $this->pdo->prepare("INSERT INTO Rastreamento (data_hora, latitude, longitude, codEntrega) VALUES (?, ?, ?, ?)");
            return $result->execute([$data_hora, $latitude, $longitude, $codEntrega]);
        }

        public function alterar($data_hora, $latitude, $longitude, $codEntrega, $cod) {
            $result = $this->pdo->prepare("UPDATE Rastreamento SET data_hora = ?, latitude = ?, longitude = ?, codEntrega = ? WHERE codRastreamento = ?");
            return $result->execute([$data_hora, $latitude, $longitude, $codEntrega, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Rastreamento WHERE codRastreamento = ?");
            return $result->execute([$cod]);
        }
    }
?>