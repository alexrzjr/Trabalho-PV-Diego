<?php
    require_once "congif/conexao.php";

    class Estoque {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Estoque");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Estoque WHERE codEstoque = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($quantidade, $validade, $codArmazem, $codProduto) {
            $result = $this->pdo->prepare("INSERT INTO Estoque (quantidade, validade, codArmazem, codProduto) VALUES (?, ?, ?, ?)");
            return $result->execute([$quantidade, $validade, $codArmazem, $codProduto]);
        }

        public function alterar($quantidade, $validade, $codArmazem, $codProduto, $cod) {
            $result = $this->pdo->prepare("UPDATE Estoque SET quantidade = ?, validade = ?, codArmazem = ?, codProduto = ? WHERE codEstoque = ?");
            return $result->execute([$quantidade, $validade, $codArmazem, $codProduto, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Estoque WHERE codEstoque = ?");
            return $result->execute([$cod]);
        }
    }
?>