<?php
    require_once "congif/conexao.php";

    class NotaFiscal {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM NotaFiscal");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM NotaFiscal WHERE codNFe = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega) {
            $result = $this->pdo->prepare("INSERT INTO NotaFiscal (tipo, valor, data_emissao, codXML, cancelada, codEntrega) VALUES (?, ?, ?, ?, ?, ?)");
            return $result->execute([$tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega]);
        }

        public function alterar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega, $cod) {
            $result = $this->pdo->prepare("UPDATE NotaFiscal SET tipo = ?, valor = ?, data_emissao = ?, codXML = ?, cancelada = ?, codEntrega = ? WHERE codNFe = ?");
            return $result->execute([$tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM NotaFiscal WHERE codNFe = ?");
            return $result->execute([$cod]);
        }
    }
?>