<?php
require_once "congif/conexao.php";

    class IndicadorLogistico {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM IndicadorLogistico");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM IndicadorLogistico WHERE codIndicadorLogistico = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora) {
            $result = $this->pdo->prepare("INSERT INTO IndicadorLogistico (data_referencia, tempo_medio_entrega, taxa_entregas_no_prazo, custo_operacional_rota, eficiencia_transportadora, codTransportadora) VALUES (?, ?, ?, ?, ?, ?)");
            return $result->execute([$data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora]);
        }

        public function alterar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora, $cod) {
            $result = $this->pdo->prepare("UPDATE IndicadorLogistico SET data_referencia = ?, tempo_medio_entrega = ?, taxa_entregas_no_prazo = ?, custo_operacional_rota = ?, eficiencia_transportadora = ?, codTransportadora = ? WHERE codIndicadorLogistico = ?");
            return $result->execute([$data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM IndicadorLogistico WHERE codIndicadorLogistico = ?");
            return $result->execute([$cod]);
        }
    }
?>