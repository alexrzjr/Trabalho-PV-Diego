<?php
    require_once "congif/conexao.php";

    class Faturamento {
        private $pdo;

        public function __construct() {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos() {
            $result = $this->pdo->query("SELECT * FROM Faturamento");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod) {
            $result = $this->pdo->prepare("SELECT * FROM Faturamento WHERE codFaturamento = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($codEntrega, $codNFe) {
            $result = $this->pdo->prepare("INSERT INTO Faturamento (codEntrega, codNFe) VALUES (?, ?)");
            return $result->execute([$codEntrega, $codNFe]);
        }

        public function alterar($codEntrega, $codNFe, $cod) {
            $result = $this->pdo->prepare("UPDATE Faturamento SET codEntrega = ?, codNFe = ? WHERE codFaturamento = ?");
            return $result->execute([$codEntrega, $codNFe, $cod]);
        }

        public function excluir($cod) {
            $result = $this->pdo->prepare("DELETE FROM Faturamento WHERE codFaturamento = ?");
            return $result->execute([$cod]);
        }
    }
?>