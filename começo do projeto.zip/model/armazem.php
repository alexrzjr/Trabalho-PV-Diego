<?php
    require_once "congif/conexao.php";

    class Armazem {
        private $pdo;

        public function __construct()
        {
            $this->pdo = Conexao::conectar();
        }

        public function listaTodos(){
            $result = $this->pdo->query("SELECT * FROM Armazem");
            return $result->fetchAll(PDO::FETCH_ASSOC);
        }

        public function listaId($cod){
            $result = $this->pdo->prepare("SELECT * FROM Armazem WHERE codArmazem = ?");
            $result->execute([$cod]);
            return $result->fetch(PDO::FETCH_ASSOC);
        }

        public function cadastrar($nome, $codEndereco){
            var_dump($nome);
            var_dump($codEndereco);
            $result = $this->pdo->prepare("INSERT INTO Armazem (nome, codEndereco) 
                                            VALUES (?, ?)");
            return $result->execute([$nome, $codEndereco]);
        }

        public function alterar($nome, $codEndereco, $cod){
            $result = $this->pdo->prepare("UPDATE Armazem SET nome = ?, codEndereco=? 
                                            WHERE nome = ?");
            return $result->execute([$nome, $codEndereco, $cod]);
        }

        public function excluir($cod){
            $result = $this->pdo->prepare("DELETE FROM Armazem 
                                            WHERE codArmazem = ?");
            return $result->execute([$cod]);
        }
    }
?>