<?php
    require_once "controller/EntregaController.php";

    $controller = new EntregaController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codEntrega'] ?? null;
        $volume = $_POST['volume'] ?? '';
        $peso = $_POST['peso'] ?? '';
        $prazo_entrega = $_POST['prazo_entrega'] ?? '';
        $codVeiculo = $_POST['codVeiculo'] ?? '';
        $codMotorista = $_POST['codMotorista'] ?? '';
        $codTransportadora = $_POST['codTransportadora'] ?? '';
        $codRota = $_POST['codRota'] ?? '';
        $codProduto = $_POST['codProduto'] ?? '';
        $statusEntrega = $_POST['statusEntrega'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formEntrega.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>