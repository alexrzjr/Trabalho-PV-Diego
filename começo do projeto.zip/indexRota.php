<?php
    require_once "controller/RotaController.php";

    $controller = new RotaController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codRota'] ?? null;
        $origem = $_POST['origem'] ?? '';
        $destino = $_POST['destino'] ?? '';
        $distancia_km = $_POST['distancia_km'] ?? '';
        $duracao_prevista = $_POST['duracao_prevista'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($origem, $destino, $distancia_km, $duracao_prevista);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $origem, $destino, $distancia_km, $duracao_prevista);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formRota.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>