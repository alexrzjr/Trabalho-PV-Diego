<?php
    require_once "controller/EnderecoController.php";

    $controller = new EnderecoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['cod'] ?? null;
        $logradouro = $_POST['logradouro'] ?? '';
        $numero = $_POST['numero'] ?? '';
        $bairro = $_POST['bairro'] ?? '';
        $cep = $_POST['cep'] ?? '';
        $cidade = $_POST['cidade'] ?? '';
        $uf = $_POST['uf'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($logradouro, $numero, $bairro, $cep, $cidade, $uf);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $logradouro, $numero, $bairro, $cep, $cidade, $uf);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formEndereco.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>