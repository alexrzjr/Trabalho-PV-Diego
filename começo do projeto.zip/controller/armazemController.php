<?php
    require_once "model/armazem.php";

    class armazemController {
        private $model;

        public function __construct(){
            $this->model = new Armazem();
        }

        public function listar(){
            $usuarios=$this->model->listaTodos();
            include "view/listarArmazem.php";
        }

        public function cadastrar($nome, $email){
            $this->model->cadastrar($nome, $email);
            header("location:cadastroArmazem.php");
        }

        public function buscaId($cod){
            $usuario = $this->model->
                listaId($cod);
            include "view/formArmazem.php";
        }

        public function alterar($cod, $nome, $email){
           $this->model->alterar($nome, $email, $cod);
            header("location:cadastroArmazem.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarArmazem.php");
        }
    }
?>