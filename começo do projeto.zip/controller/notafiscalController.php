<?php
    require_once "model/notafiscal.php";

    class notafiscalController {
        private $model;

        public function __construct(){
            $this->model = new NotaFiscal();
        }

        public function listar(){
            $notasFiscais = $this->model->listaTodos();
            include "view/listarNotaFiscal.php";
        }

        public function cadastrar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega){
            $this->model->cadastrar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega);
            header("location:cadastroNotaFiscal.php");
        }

        public function buscaId($cod){
            $notaFiscal = $this->model->listaId($cod);
            include "view/formNotaFiscal.php";
        }

        public function alterar($cod, $tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega){
            $this->model->alterar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega, $cod);
            header("location:cadastroNotaFiscal.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarNotaFiscal.php");
        }
    }
?>