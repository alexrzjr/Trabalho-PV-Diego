<?php
    require_once "model/veiculo.php";

    class veiculoController {
        private $model;

        public function __construct(){
            $this->model = new Veiculo();
        }

        public function listar(){
            $veiculos = $this->model->listaTodos();
            include "view/listarVeiculo.php";
        }

        public function cadastrar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo){
            $this->model->cadastrar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo);
            header("location:cadastroVeiculo.php");
        }

        public function buscaId($cod){
            $veiculo = $this->model->listaId($cod);
            include "view/formVeiculo.php";
        }

        public function alterar($cod, $placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo){
            $this->model->alterar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo, $cod);
            header("location:cadastroVeiculo.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarVeiculo.php");
        }
    }
?>