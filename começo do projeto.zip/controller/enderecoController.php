<?php
    require_once "model/Endereco.php";

    class enderecoController {
        private $model;

        public function __construct(){
            $this->model = new Endereco();
        }

        public function listar(){
            $usuarios=$this->model->listaTodos();
            include "view/listarEndereco.php";
        }

        public function cadastrar($nome, $logradouro, $numero, $bairro, $cep, $cidade, $uf){
            $this->model->cadastrar($nome, $logradouro, $numero, $bairro, $cep, $cidade, $uf);
            header("location:cadastroEndereco.php");
        }

        public function buscaId($cod){
            $usuario = $this->model->
                listaId($cod);
            include "view/formEndereco.php";
        }

        public function alterar($cod, $nome, $email){
           $this->model->alterar($nome, $email, 
                $cod);
            header("location:cadastroEndereco.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarEndereco.php");
        }
    }
?>