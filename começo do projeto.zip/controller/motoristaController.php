<?php
    require_once "model/motorista.php";

    class motoristaController {
        private $model;

        public function __construct(){
            $this->model = new Motorista();
        }

        public function listar(){
            $motoristas = $this->model->listaTodos();
            include "view/listarMotorista.php";
        }

        public function cadastrar($nome, $cnh, $telefone, $codTransportadora){
            $this->model->cadastrar($nome, $cnh, $telefone, $codTransportadora);
            header("location:cadastroMotorista.php");
        }

        public function buscaId($cod){
            $motorista = $this->model->listaId($cod);
            include "view/formMotorista.php";
        }

        public function alterar($cod, $nome, $cnh, $telefone, $codTransportadora){
            $this->model->alterar($nome, $cnh, $telefone, $codTransportadora, $cod);
            header("location:cadastroMotorista.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarMotorista.php");
        }
    }
?>