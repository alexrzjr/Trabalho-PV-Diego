<?php
    require_once "model/rastreamento.php";

    class rastreamentoController {
        private $model;

        public function __construct(){
            $this->model = new Rastreamento();
        }

        public function listar(){
            $rastreamentos = $this->model->listaTodos();
            include "view/listarRastreamento.php";
        }

        public function cadastrar($data_hora, $latitude, $longitude, $codEntrega){
            $this->model->cadastrar($data_hora, $latitude, $longitude, $codEntrega);
            header("location:cadastroRastreamento.php");
        }

        public function buscaId($cod){
            $rastreamento = $this->model->listaId($cod);
            include "view/formRastreamento.php";
        }

        public function alterar($cod, $data_hora, $latitude, $longitude, $codEntrega){
            $this->model->alterar($data_hora, $latitude, $longitude, $codEntrega, $cod);
            header("location:cadastroRastreamento.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarRastreamento.php");
        }
    }
?>