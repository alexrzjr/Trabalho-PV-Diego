<?php
    require_once "model/indicadorlogistico.php";

    class indicadorLogisticoController {
        private $model;

        public function __construct(){
            $this->model = new IndicadorLogistico();
        }

        public function listar(){
            $indicadores = $this->model->listaTodos();
            include "view/listarIndicadorLogistico.php";
        }

        public function cadastrar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora){
            $this->model->cadastrar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora);
            header("location:cadastroIndicadorLogistico.php");
        }

        public function buscaId($cod){
            $indicador = $this->model->listaId($cod);
            include "view/formIndicadorLogistico.php";
        }

        public function alterar($cod, $data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora){
            $this->model->alterar($data_referencia, $tempo_medio_entrega, $taxa_entregas_no_prazo, $custo_operacional_rota, $eficiencia_transportadora, $codTransportadora, $cod);
            header("location:cadastroIndicadorLogistico.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarIndicadorLogistico.php");
        }
    }
?>