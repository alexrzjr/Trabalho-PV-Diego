<?php
    require_once "model/transportadora.php";

    class transportadoraController {
        private $model;

        public function __construct(){
            $this->model = new Transportadora();
        }

        public function listar(){
            $transportadoras = $this->model->listaTodos();
            include "view/listarTransportadora.php";
        }

        public function cadastrar($cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco){
            $this->model->cadastrar($cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco);
            header("location:cadastroTransportadora.php");
        }

        public function buscaId($cod){
            $transportadora = $this->model->listaId($cod);
            include "view/formTransportadora.php";
        }

        public function alterar($cod, $cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco){
            $this->model->alterar($cnpj, $nome_fantasia, $razao_social, $IE, $contato, $codEndereco, $cod);
            header("location:cadastroTransportadora.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarTransportadora.php");
        }
    }
?>