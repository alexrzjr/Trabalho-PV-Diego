<?php
    require_once "model/faturamento.php";

    class faturamentoController {
        private $model;

        public function __construct(){
            $this->model = new Faturamento();
        }

        public function listar(){
            $faturamentos = $this->model->listaTodos();
            include "view/listarFaturamento.php";
        }

        public function cadastrar($codEntrega, $codNFe){
            $this->model->cadastrar($codEntrega, $codNFe);
            header("location:cadastroFaturamento.php");
        }

        public function buscaId($cod){
            $faturamento = $this->model->listaId($cod);
            include "view/formFaturamento.php";
        }

        public function alterar($cod, $codEntrega, $codNFe){
            $this->model->alterar($codEntrega, $codNFe, $cod);
            header("location:cadastroFaturamento.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarFaturamento.php");
        }
    }
?>