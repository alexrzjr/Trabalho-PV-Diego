<?php
    require_once "model/rota.php";

    class rotaController {
        private $model;

        public function __construct(){
            $this->model = new Rota();
        }

        public function listar(){
            $rotas = $this->model->listaTodos();
            include "view/listarRota.php";
        }

        public function cadastrar($origem, $destino, $distancia_km, $duracao_prevista){
            $this->model->cadastrar($origem, $destino, $distancia_km, $duracao_prevista);
            header("location:cadastroRota.php");
        }

        public function buscaId($cod){
            $rota = $this->model->listaId($cod);
            include "view/formRota.php";
        }

        public function alterar($cod, $origem, $destino, $distancia_km, $duracao_prevista){
            $this->model->alterar($origem, $destino, $distancia_km, $duracao_prevista, $cod);
            header("location:cadastroRota.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarRota.php");
        }
    }
?>