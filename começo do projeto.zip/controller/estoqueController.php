<?php
    require_once "model/estoque.php";

    class estoqueController {
        private $model;

        public function __construct(){
            $this->model = new Estoque();
        }

        public function listar(){
            $estoques = $this->model->listaTodos();
            include "view/listarEstoque.php";
        }

        public function cadastrar($quantidade, $validade, $codArmazem, $codProduto){
            $this->model->cadastrar($quantidade, $validade, $codArmazem, $codProduto);
            header("location:cadastroEstoque.php");
        }

        public function buscaId($cod){
            $estoque = $this->model->listaId($cod);
            include "view/formEstoque.php";
        }

        public function alterar($cod, $quantidade, $validade, $codArmazem, $codProduto){
            $this->model->alterar($quantidade, $validade, $codArmazem, $codProduto, $cod);
            header("location:cadastroEstoque.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarEstoque.php");
        }
    }
?>