<?php
    require_once "model/produto.php";

    class produtoController {
        private $model;

        public function __construct(){
            $this->model = new Produto();
        }

        public function listar(){
            $produtos = $this->model->listaTodos();
            include "view/listarProduto.php";
        }

        public function cadastrar($nome, $categoriaProduto){
            $this->model->cadastrar($nome, $categoriaProduto);
            header("location:cadastroProduto.php");
        }

        public function buscaId($cod){
            $produto = $this->model->listaId($cod);
            include "view/formProduto.php";
        }

        public function alterar($cod, $nome, $categoriaProduto){
            $this->model->alterar($nome, $categoriaProduto, $cod);
            header("location:cadastroProduto.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarProduto.php");
        }
    }
?>