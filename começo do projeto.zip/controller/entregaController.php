<?php
require_once "model/entrega.php";

    class entregaController {
        private $model;

        public function __construct(){
            $this->model = new Entrega();
        }

        public function listar(){
            $entregas = $this->model->listaTodos();
            include "view/listarEntrega.php";
        }

        public function cadastrar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega){
            $this->model->cadastrar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega);
            header("location:cadastroEntrega.php");
        }

        public function buscaId($cod){
            $entrega = $this->model->listaId($cod);
            include "view/formEntrega.php";
        }

        public function alterar($cod, $volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega){
            $this->model->alterar($volume, $peso, $prazo_entrega, $codVeiculo, $codMotorista, $codTransportadora, $codRota, $codProduto, $statusEntrega, $cod);
            header("location:cadastroEntrega.php");
        }

        public function excluir($cod){
            $this->model->excluir($cod);
            header("location:listarEntrega.php");
        }
    }
?>