<?php
    require_once "controller/MotoristaController.php";

    $controller = new MotoristaController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['cod'] ?? null;
        $nome = $_POST['nome'] ?? '';
        $cnh = $_POST['cnh'] ?? '';
        $telefone = $_POST['telefone'] ?? '';
        $codTransportadora = $_POST['codTransportadora'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($nome, $cnh, $telefone, $codTransportadora);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $nome, $cnh, $telefone, $codTransportadora);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formMotorista.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>