<?php
    require_once "controller/RastreamentoController.php";

    $controller = new RastreamentoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codRastreamento'] ?? null;
        $data_hora = $_POST['data_hora'] ?? null;
        $latitude = $_POST['latitude'] ?? '';
        $longitude = $_POST['longitude'] ?? '';
        $codEntrega = $_POST['codEntrega'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($data_hora, $latitude, $longitude, $codEntrega);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $data_hora, $latitude, $longitude, $codEntrega);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formRastreamento.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>