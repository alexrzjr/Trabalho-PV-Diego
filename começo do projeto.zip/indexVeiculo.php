<?php
    require_once "controller/VeiculoController.php";

    $controller = new VeiculoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codVeiculo'] ?? null;
        $placa = $_POST['placa'] ?? '';
        $capacidade_carga = $_POST['capacidade_carga'] ?? '';
        $codMotorista = $_POST['codMotorista'] ?? '';
        $codTransportadora = $_POST['codTransportadora'] ?? '';
        $statusVeiculo = $_POST['statusVeiculo'] ?? '';
        $categoriaVeiculo = $_POST['categoriaVeiculo'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $placa, $capacidade_carga, $codMotorista, $codTransportadora, $statusVeiculo, $categoriaVeiculo);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formVeiculo.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>