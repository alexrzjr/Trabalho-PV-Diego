<?php
    require_once "controller/ProdutoController.php";

    $controller = new ProdutoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codProduto'] ?? null;
        $nome = $_POST['nome'] ?? '';
        $categoriaProduto = $_POST['categoriaProduto'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($nome, $categoriaProduto);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $nome, $categoriaProduto);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formProduto.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>