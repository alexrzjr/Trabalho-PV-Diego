<?php
    require_once "controller/FaturamentoController.php";

    $controller = new FaturamentoController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codFaturamento'] ?? null;
        $codEntrega = $_POST['codEntrega'] ?? '';
        $codNFe = $_POST['codNFe'] ?? null;

        if ($acao === 'cadastrar') {
            $controller->cadastrar($codEntrega, $codNFe);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $codEntrega, $codNFe);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formFaturamento.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>