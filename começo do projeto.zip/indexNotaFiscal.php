<?php
    require_once "controller/NotaFiscalController.php";

    $controller = new NotaFiscalController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codNFe'] ?? null;
        $tipo = $_POST['tipo'] ?? '';
        $valor = $_POST['valor'] ?? '';
        $data_emissao = $_POST['data_emissao'] ?? '';
        $codXML = $_POST['codXML'] ?? '';
        $cancelada = isset($_POST['cancelada']) ? 1 : 0;
        $codEntrega = $_POST['codEntrega'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $tipo, $valor, $data_emissao, $codXML, $cancelada, $codEntrega);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formNotaFiscal.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>