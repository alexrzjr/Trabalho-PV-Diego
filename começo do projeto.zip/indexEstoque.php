<?php
    require_once "controller/EstoqueController.php";

    $controller = new EstoqueController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['codEstoque'] ?? null;
        $quantidade = $_POST['quantidade'] ?? '';
        $validade = $_POST['validade'] ?? '';
        $codArmazem = $_POST['codArmazem'] ?? '';
        $codProduto = $_POST['codProduto'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($quantidade, $validade, $codArmazem, $codProduto);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $quantidade, $validade, $codArmazem, $codProduto);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formEstoque.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>