<h1>Rastreamentos</h1>
<a href="rastreamento.php?acao=novo">Novo Rastreamento</a>
<ul>
    <?php foreach ($rastreamentos as $rastreamento): ?>
        <li>
            Entrega: <?php echo $rastreamento['codEntrega']; ?> -
            Data/Hora: <?php echo $rastreamento['data_hora']; ?> -
            Latitude: <?php echo $rastreamento['latitude']; ?>,
            Longitude: <?php echo $rastreamento['longitude']; ?>
            <a href="rastreamento.php?acao=editar&id=<?php echo $rastreamento['codRastreamento'] ?>">Editar</a>
            <a href="rastreamento.php?acao=excluir&id=<?php echo $rastreamento['codRastreamento'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
