<h1><?php echo isset($armazem) ? 'Editar' : 'Cadastrar' ?> Armazém</h1>
<form action="armazem.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($armazem) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($armazem)){ ?>
        <input type="hidden" name="cod" value="<?php echo $armazem["codArmazem"] ?>">
    <?php } ?>

    <label>Nome: </label>
    <input type="text" name="nome" value="<?= $armazem['nome'] ?? '' ?>">

    <label>Endereço: </label>
    <input type="text" name="codEndereco" value="<?= $armazem['codEndereco'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="armazem.php">Voltar</a>
