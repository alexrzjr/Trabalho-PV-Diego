<h1><?php echo isset($item) ? 'Editar' : 'Cadastrar' ?></h1>
<form action="indexTransportadora.php" method="post">
    <input type="hidden" name="acao"
    value="<?php echo isset($item) ? 
        'atualizar' : 'cadastrar' ?>">
    <?php if(isset($item)){ ?>
        <input type="hidden" name="cod" value="<?php echo $item["codTransportadora"] ?>">
    <?php } ?>
    <label>CNPJ: </label>
    <input type="text" name="cnpj" value="<?= $item['cnpj'] ?? '' ?>">

    <label>Nome Fantasia: </label>
    <input type="text" name="nome_fantasia" value="<?= $item['nome_fantasia'] ?? '' ?>">

    <label>Razão Social: </label>
    <input type="text" name="razao_social" value="<?= $item['razao_social'] ?? '' ?>">
    
    <label>Inscrição Estadual:</label>
    <input type="text" name="IE" value="<?= $item['IE'] ?? '' ?>">
    
    <label>Contato: </label>
    <input type="text" name="contato" value="<?= $item['contato'] ?? '' ?>">
    
    <label>Endereço:</label>
    <input type="text" name="codEndereco" value="<?= $item['codEndereco'] ?? '' ?>">
    
    <input type="submit" value="Salvar">
</form>
<a href="transportadora.php">Voltar</a>