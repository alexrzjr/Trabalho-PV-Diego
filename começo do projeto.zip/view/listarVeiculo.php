<h1>Veículos</h1>
<a href="veiculo.php?acao=novo">Novo Veículo</a>
<ul>
    <?php foreach ($veiculos as $veiculo): ?>
        <li>
            <?php echo $veiculo['placa']; ?> - <?php echo $veiculo['categoriaVeiculo']; ?> (<?php echo $veiculo['statusVeiculo']; ?>)
            <a href="veiculo.php?acao=editar&id=<?php echo $veiculo['codVeiculo'] ?>">Editar</a>
            <a href="veiculo.php?acao=excluir&id=<?php echo $veiculo['codVeiculo'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
