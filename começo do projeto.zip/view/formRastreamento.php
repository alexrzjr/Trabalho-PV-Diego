<h1><?php echo isset($rastreamento) ? 'Editar' : 'Cadastrar' ?> Rastreamento</h1>
<form action="rastreamento.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($rastreamento) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($rastreamento)){ ?>
        <input type="hidden" name="cod" value="<?php echo $rastreamento["codRastreamento"] ?>">
    <?php } ?>

    <label>Data e Hora: </label>
    <input type="datetime-local" name="data_hora" value="<?= isset($rastreamento['data_hora']) ? date('Y-m-d\TH:i', strtotime($rastreamento['data_hora'])) : '' ?>">

    <label>Latitude: </label>
    <input type="text" name="latitude" value="<?= $rastreamento['latitude'] ?? '' ?>">

    <label>Longitude: </label>
    <input type="text" name="longitude" value="<?= $rastreamento['longitude'] ?? '' ?>">

    <label>Entrega: </label>
    <input type="text" name="codEntrega" value="<?= $rastreamento['codEntrega'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="rastreamento.php">Voltar</a>
