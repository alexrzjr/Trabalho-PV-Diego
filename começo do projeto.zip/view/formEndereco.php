<h1><?php echo isset($item) ? 'Editar' : 'Cadastrar' ?> Endereço</h1>
<form action="indexEndereco.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($item) ? 'atualizar' : 'cadastrar' ?>">
    <?php if (isset($item)) { ?>
        <input type="hidden" name="cod" value="<?php echo $item['codEndereco'] ?>">
    <?php } ?>

    <label>Logradouro:</label>
    <input type="text" name="logradouro" value="<?= $item['logradouro'] ?? '' ?>">

    <label>Número:</label>
    <input type="text" name="numero" value="<?= $item['numero'] ?? '' ?>">

    <label>Bairro:</label>
    <input type="text" name="bairro" value="<?= $item['bairro'] ?? '' ?>">

    <label>CEP:</label>
    <input type="text" name="cep" value="<?= $item['cep'] ?? '' ?>">

    <label>Cidade:</label>
    <input type="text" name="cidade" value="<?= $item['cidade'] ?? '' ?>">

    <label>UF:</label>
    <input type="text" name="uf" value="<?= $item['uf'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="endereco.php">Voltar</a>
