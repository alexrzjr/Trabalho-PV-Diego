<h1><?php echo isset($produto) ? 'Editar' : 'Cadastrar' ?> Produto</h1>
<form action="produto.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($produto) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($produto)){ ?>
        <input type="hidden" name="cod" value="<?php echo $produto["codProduto"] ?>">
    <?php } ?>

    <label>Nome: </label>
    <input type="text" name="nome" value="<?= $produto['nome'] ?? '' ?>">

    <label>Produto: </label>
    <select name="categoriaProduto" value="<?= $entrega['categoriaProduto'] ?? '' ?>">
        <?php
            $categoriaProduto = ['Carga Geral', 'Carga a Granel', 'Carga Frigorificada', 'Carga Viva', 'Carga Perigosa', 'Carga Frágil', 'Cargas Indivisíveis e Excepcionais de Grande Porte', 'Cargas Específicas'];
            foreach($categoriaProduto as $cat){
                $selected = (isset($item['categoriaProduto']) $$ $item['categoriaProduto'] === $cat) ? 'selected' : '';
                echo "<option value='$cat' $selected>$cat</option>";
            }
        ?>
    </select>

    <input type="submit" value="Salvar">
</form>
<a href="produto.php">Voltar</a>
