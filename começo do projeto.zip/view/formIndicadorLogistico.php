<h1><?php echo isset($indicador) ? 'Editar' : 'Cadastrar' ?> Indicador Logístico</h1>
<form action="indicadorLogistico.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($indicador) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($indicador)){ ?>
        <input type="hidden" name="cod" value="<?php echo $indicador['codIndicadorLogistico'] ?>">
    <?php } ?>

    <label>Data de Referência: </label>
    <input type="date" name="data_referencia" value="<?= $indicador['data_referencia'] ?? '' ?>">

    <label>Tempo Médio de Entrega: </label>
    <input type="text" name="tempo_medio_entrega" value="<?= $indicador['tempo_medio_entrega'] ?? '' ?>">

    <label>Taxa de Entregas no Prazo: </label>
    <input type="text" name="taxa_entregas_no_prazo" value="<?= $indicador['taxa_entregas_no_prazo'] ?? '' ?>">

    <label>Custo Operacional da Rota: </label>
    <input type="text" name="custo_operacional_rota" value="<?= $indicador['custo_operacional_rota'] ?? '' ?>">

    <label>Eficiência da Transportadora: </label>
    <input type="text" name="eficiencia_transportadora" value="<?= $indicador['eficiencia_transportadora'] ?? '' ?>">

    <label>Transportadora: </label>
    <input type="text" name="codTransportadora" value="<?= $indicador['codTransportadora'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="indicadorLogistico.php">Voltar</a>
