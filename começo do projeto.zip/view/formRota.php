<h1><?php echo isset($rota) ? 'Editar' : 'Cadastrar' ?> Rota</h1>
<form action="rota.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($rota) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($rota)){ ?>
        <input type="hidden" name="cod" value="<?php echo $rota["codRota"] ?>">
    <?php } ?>

    <label>Origem (Código do Endereço): </label>
    <input type="text" name="origem" value="<?= $rota['origem'] ?? '' ?>">

    <label>Destino (Código do Endereço): </label>
    <input type="text" name="destino" value="<?= $rota['destino'] ?? '' ?>">

    <label>Distância (km): </label>
    <input type="text" name="distancia_km" value="<?= $rota['distancia_km'] ?? '' ?>">

    <label>Duração Prevista: </label>
    <input type="text" name="duracao_prevista" value="<?= $rota['duracao_prevista'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="rota.php">Voltar</a>