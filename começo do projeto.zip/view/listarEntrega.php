<h1>Entregas</h1>
<a href="entrega.php?acao=novo">Nova Entrega</a>
<ul>
    <?php foreach ($entregas as $entrega): ?>
        <li>
            Produto: <?php echo $entrega['codProduto']; ?> -
            Veículo: <?php echo $entrega['codVeiculo']; ?> -
            Status: <?php echo $entrega['statusEntrega']; ?> -
            Prazo: <?php echo $entrega['prazo_entrega']; ?>
            <a href="entrega.php?acao=editar&id=<?php echo $entrega['codEntrega'] ?>">Editar</a>
            <a href="entrega.php?acao=excluir&id=<?php echo $entrega['codEntrega'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
