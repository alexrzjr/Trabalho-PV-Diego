<h1><?php echo isset($notaFiscal) ? 'Editar' : 'Cadastrar' ?> Nota Fiscal</h1>
<form action="notaFiscal.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($notaFiscal) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($notaFiscal)){ ?>
        <input type="hidden" name="cod" value="<?php echo $notaFiscal['codNFe'] ?>">
    <?php } ?>

    <label>Tipo: </label>
    <input type="text" name="tipo" value="<?= $notaFiscal['tipo'] ?? '' ?>">

    <label>Valor: </label>
    <input type="text" name="valor" value="<?= $notaFiscal['valor'] ?? '' ?>">

    <label>Data de Emissão: </label>
    <input type="date" name="data_emissao" value="<?= $notaFiscal['data_emissao'] ?? '' ?>">

    <label>Código XML: </label>
    <input type="text" name="codXML" value="<?= $notaFiscal['codXML'] ?? '' ?>">

    <label>Cancelada (0 ou 1): </label>
    <select name="cancelada" value="<?= $notaFiscal['cancelada'] ?? '' ?>">
        <option value="0">Falso</option>
        <option value="1">Verdadeiro</option>
    </select>

    <label>Entrega: </label>
    <input type="text" name="codEntrega" value="<?= $notaFiscal['codEntrega'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="notaFiscal.php">Voltar</a>
