<h1>Produtos</h1>
<a href="produto.php?acao=novo">Novo Produto</a>
<ul>
    <?php foreach ($produtos as $produto): ?>
        <li>
            <?php echo $produto['nome']; ?> - <?php echo $produto['categoriaProduto']; ?>
            <a href="produto.php?acao=editar&id=<?php echo $produto['codProduto'] ?>">Editar</a>
            <a href="produto.php?acao=excluir&id=<?php echo $produto['codProduto'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
