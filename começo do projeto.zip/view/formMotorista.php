<h1><?php echo isset($motorista) ? 'Editar' : 'Cadastrar' ?> Motorista</h1>
<form action="motorista.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($motorista) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($motorista)){ ?>
        <input type="hidden" name="cod" value="<?php echo $motorista["codMotorista"] ?>">
    <?php } ?>

    <label>Nome: </label>
    <input type="text" name="nome" value="<?= $motorista['nome'] ?? '' ?>">

    <label>CNH: </label>
    <input type="text" name="cnh" value="<?= $motorista['cnh'] ?? '' ?>">

    <label>Telefone: </label>
    <input type="text" name="telefone" value="<?= $motorista['telefone'] ?? '' ?>">

    <label>Transportadora: </label>
    <input type="text" name="codTransportadora" value="<?= $motorista['codTransportadora'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="motorista.php">Voltar</a>
