<h1><?php echo isset($estoque) ? 'Editar' : 'Cadastrar' ?> Estoque</h1>
<form action="estoque.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($estoque) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($estoque)){ ?>
        <input type="hidden" name="cod" value="<?php echo $estoque["codEstoque"] ?>">
    <?php } ?>

    <label>Quantidade: </label>
    <input type="text" name="quantidade" value="<?= $estoque['quantidade'] ?? '' ?>">

    <label>Validade: </label>
    <input type="text" name="validade" value="<?= $estoque['validade'] ?? '' ?>">

    <label>Armazém: </label>
    <input type="text" name="codArmazem" value="<?= $estoque['codArmazem'] ?? '' ?>">

    <label>Produto: </label>
    <input type="text" name="codProduto" value="<?= $estoque['codProduto'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="estoque.php">Voltar</a>
