<h1>Rotas</h1>
<a href="rota.php?acao=novo">Nova Rota</a>
<ul>
    <?php foreach ($rotas as $rota): ?>
        <li>
            Origem: <?php echo $rota['origem']; ?> → Destino: <?php echo $rota['destino']; ?> -
            Distância: <?php echo $rota['distancia_km']; ?> km -
            Duração: <?php echo $rota['duracao_prevista']; ?>
            <a href="rota.php?acao=editar&id=<?php echo $rota['codRota'] ?>">Editar</a>
            <a href="rota.php?acao=excluir&id=<?php echo $rota['codRota'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
