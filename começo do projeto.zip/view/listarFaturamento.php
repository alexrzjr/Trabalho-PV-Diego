<h1>Faturamentos</h1>
<a href="faturamento.php?acao=novo">Novo Faturamento</a>
<ul>
    <?php foreach ($faturamentos as $faturamento): ?>
        <li>
            Entrega: <?php echo $faturamento['codEntrega']; ?> -
            Nota Fiscal: <?php echo $faturamento['codNFe'] ?? 'N/A'; ?>
            <a href="faturamento.php?acao=editar&id=<?php echo $faturamento['codFaturamento'] ?>">Editar</a>
            <a href="faturamento.php?acao=excluir&id=<?php echo $faturamento['codFaturamento'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
