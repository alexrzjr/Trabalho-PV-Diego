<h1><?php echo isset($veiculo) ? 'Editar' : 'Cadastrar' ?> Veículo</h1>
<form action="veiculo.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($veiculo) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($veiculo)){ ?>
        <input type="hidden" name="cod" value="<?php echo $veiculo["codVeiculo"] ?>">
    <?php } ?>

    <label>Placa: </label>
    <input type="text" name="placa" value="<?= $veiculo['placa'] ?? '' ?>">

    <label>Capacidade de Carga: </label>
    <input type="text" name="capacidade_carga" value="<?= $veiculo['capacidade_carga'] ?? '' ?>">

    <label>Motorista: </label>
    <input type="text" name="codMotorista" value="<?= $veiculo['codMotorista'] ?? '' ?>">

    <label>Transportadora: </label>
    <input type="text" name="codTransportadora" value="<?= $veiculo['codTransportadora'] ?? '' ?>">

    <label>Status do Veículo: </label>
    <select name="statusVeiculo" value="<?= $entrega['statusVeiculo'] ?? '' ?>">
        <?php
            $statusVeiculo = ['Disponível', 'Em uso', 'Manutenção'];
            foreach($statusVeiculo as $sts){
                $selected = (isset($item['statusVeiculo']) $$ $item['statusVeiculo'] === $sts) ? 'selected' : '';
                echo "<option value='$sts' $selected>$sts</option>";
            }
        ?>
    </select>

    <label>Categoria do Veículo: </label>
    <input type="text" name="categoriaVeiculo" value="<?= $veiculo['categoriaVeiculo'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="veiculo.php">Voltar</a>
