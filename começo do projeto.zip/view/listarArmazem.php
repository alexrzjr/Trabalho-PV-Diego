<h1>Armazéns</h1>
<a href="armazem.php?acao=novo">Novo Armazém</a>
<ul>
    <?php foreach ($armazens as $armazem): ?>
        <li>
            <?php echo $armazem['nome']; ?> (Endereço: <?php echo $armazem['codEndereco']; ?>)
            <a href="armazem.php?acao=editar&id=<?php echo $armazem['codArmazem'] ?>">Editar</a>
            <a href="produto.php?acao=excluir&id=<?php echo $produto['codProduto'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
