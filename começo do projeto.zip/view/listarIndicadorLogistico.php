<h1>Indicadores Logísticos</h1>
<a href="indicadorLogistico.php?acao=novo">Novo Indicador</a>
<ul>
    <?php foreach ($indicadores as $indicador): ?>
        <li>
            Data: <?php echo $indicador['data_referencia']; ?> -
            Eficiência: <?php echo $indicador['eficiencia_transportadora']; ?>%
            <a href="indicadorLogistico.php?acao=editar&id=<?php echo $indicador['codIndicadorLogistico'] ?>">Editar</a>
            <a href="indicadorLogistico.php?acao=excluir&id=<?php echo $indicador['codIndicadorLogistico'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
