<h1>Endereços</h1>
<a href="endereco.php?acao=novo">Novo Endereço</a>
<ul>
    <?php foreach ($itens as $item): ?>
        <li>
            <?php echo $item['logradouro'] . ', ' . $item['numero'] . ' - ' . $item['bairro'] . ', ' . $item['cidade'] . '/' . $item['uf']; ?>
            <a href="endereco.php?acao=editar&id=<?php echo $item['codEndereco'] ?>">Editar</a>
            <a href="endereco.php?acao=excluir&id=<?php echo $item['codEndereco'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
