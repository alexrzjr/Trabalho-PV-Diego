<h1><?php echo isset($faturamento) ? 'Editar' : 'Cadastrar' ?> Faturamento</h1>
<form action="faturamento.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($faturamento) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($faturamento)){ ?>
        <input type="hidden" name="cod" value="<?php echo $faturamento['codFaturamento'] ?>">
    <?php } ?>

    <label>Entrega: </label>
    <input type="text" name="codEntrega" value="<?= $faturamento['codEntrega'] ?? '' ?>">

    <label>Nota Fiscal: </label>
    <input type="text" name="codNFe" value="<?= $faturamento['codNFe'] ?? '' ?>">

    <input type="submit" value="Salvar">
</form>
<a href="faturamento.php">Voltar</a>
