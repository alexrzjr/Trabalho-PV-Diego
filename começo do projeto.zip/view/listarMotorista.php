<ul>
    <?php foreach ($motoristas as $motorista): ?>
        <li>
            <?php echo $motorista['nome']; ?> -
            CNH: <?php echo $motorista['cnh']; ?>
            <a href="motorista.php?acao=editar&id=<?php echo $motorista['codMotorista'] ?>">Editar</a>
            <a href="motorista.php?acao=excluir&id=<?php echo $motorista['codMotorista'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
