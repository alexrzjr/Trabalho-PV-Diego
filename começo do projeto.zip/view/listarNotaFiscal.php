<h1>Notas Fiscais</h1>
<a href="notaFiscal.php?acao=novo">Nova Nota Fiscal</a>
<ul>
    <?php foreach ($notasFiscais as $notaFiscal): ?>
        <li>
            Tipo: <?php echo $notaFiscal['tipo']; ?> -
            Valor: R$<?php echo $notaFiscal['valor']; ?> -
            XML: <?php echo $notaFiscal['codXML']; ?> -
            Entrega: <?php echo $notaFiscal['codEntrega']; ?> -
            Cancelada: <?php echo $notaFiscal['cancelada'] ? 'Sim' : 'Não'; ?>
            <a href="notaFiscal.php?acao=editar&id=<?php echo $notaFiscal['codNFe'] ?>">Editar</a>
            <a href="notaFiscal.php?acao=excluir&id=<?php echo $notaFiscal['codNFe'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
