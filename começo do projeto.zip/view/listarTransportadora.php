<!-- listarLivros.php -->
<h1>Transportadora</h1>
<a href="transportadora.php?acao=novo">Nova Transportadora</a>
<ul>
    <?php foreach ($itens as $item): ?>
        <li>
            <?php echo $item['cnpj']; ?> - 
            (<?php echo $item['nome_fantasia']; ?>)
            <a href="transportadora.php?acao=editar&cod=<?php echo $item['codTransportadora'] ?>">Editar</a>
            <a href="transportadora.php?acao=excluir&cod=<?php echo $item['codTransportadora'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>