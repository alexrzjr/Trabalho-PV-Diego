<h1>Estoques</h1>
<a href="estoque.php?acao=novo">Novo Estoque</a>
<ul>
    <?php foreach ($estoques as $estoque): ?>
        <li>
            Quantidade: <?php echo $estoque['quantidade']; ?> - Validade: <?php echo $estoque['validade']; ?>
            (Armazém: <?php echo $estoque['codArmazem']; ?>, Produto: <?php echo $estoque['codProduto']; ?>)
            <a href="estoque.php?acao=editar&id=<?php echo $estoque['codEstoque'] ?>">Editar</a>
            <a href="estoque.php?acao=excluir&id=<?php echo $estoque['codEstoque'] ?>">Excluir</a>
        </li>
    <?php endforeach; ?>
</ul>
