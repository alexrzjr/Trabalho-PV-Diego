<h1><?php echo isset($entrega) ? 'Editar' : 'Cadastrar' ?> Entrega</h1>
<form action="entrega.php" method="post">
    <input type="hidden" name="acao" value="<?php echo isset($entrega) ? 'atualizar' : 'cadastrar' ?>">
    <?php if(isset($entrega)){ ?>
        <input type="hidden" name="cod" value="<?php echo $entrega["codEntrega"] ?>">
    <?php } ?>

    <label>Volume: </label>
    <input type="text" name="volume" value="<?= $entrega['volume'] ?? '' ?>">

    <label>Peso: </label>
    <input type="text" name="peso" value="<?= $entrega['peso'] ?? '' ?>">

    <label>Prazo de Entrega: </label>
    <input type="date" name="prazo_entrega" value="<?= $entrega['prazo_entrega'] ?? '' ?>">

    <label>Veículo: </label>
    <input type="text" name="codVeiculo" value="<?= $entrega['codVeiculo'] ?? '' ?>">

    <label>Motorista: </label>
    <input type="text" name="codMotorista" value="<?= $entrega['codMotorista'] ?? '' ?>">

    <label>Transportadora: </label>
    <input type="text" name="codTransportadora" value="<?= $entrega['codTransportadora'] ?? '' ?>">

    <label>Rota: </label>
    <input type="text" name="codRota" value="<?= $entrega['codRota'] ?? '' ?>">

    <label>Produto: </label>
    <input type="text" name="codProduto" value="<?= $entrega['codProduto'] ?? '' ?>">

    <label>Status da entrega: </label>
    <select name="statusEntrega" value="<?= $entrega['statusEntrega'] ?? '' ?>">
        <?php
            $statusEntrega = ['Pendente', 'Em Andamento', 'Entregue', 'Cancelada'];
            foreach($statusEntrega as $sts){
                $selected = (isset($item['statusEntrega']) $$ $item['statusEntrega'] === $sts) ? 'selected' : '';
                echo "<option value='$sts' $selected>$sts</option>";
            }
        ?>
    </select>

    <input type="submit" value="Salvar">
</form>
<a href="entrega.php">Voltar</a>
