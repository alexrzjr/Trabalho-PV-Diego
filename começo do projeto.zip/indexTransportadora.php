<?php
    require_once "controller/TransportadoraController.php";

    $controller = new TransportadoraController();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $acao = $_POST['acao'] ?? '';
        $cod = $_POST['cod'] ?? null;
        $cnpj = $_POST['cnpj'] ?? '';
        $nome_fantasia = $_POST['nome_fantasia'] ?? '';
        $razao_social = $_POST['razao_social'] ?? '';
        $IE = $_POST['IE'] ?? '';
        $contato = $_POST['contato'] ?? '';

        if ($acao === 'cadastrar') {
            $controller->cadastrar($cnpj, $nome_fantasia, $razao_social, $IE, $contato);
        } elseif ($acao === 'atualizar' && $cod !== null) {
            $controller->alterar($cod, $cnpj, $nome_fantasia, $razao_social, $IE, $contato);
        }
    } elseif (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
        $id = $_GET['id'] ?? null;

        if ($acao === 'editar' && $id !== null) {
            $controller->buscaId($id);
        } elseif ($acao === 'excluir' && $id !== null) {
            $controller->excluir($id);
        } elseif ($acao === 'novo') {
            include "view/formTransportadora.php";
        } else {
            $controller->listar();
        }
    } else {
        $controller->listar();
    }
?>